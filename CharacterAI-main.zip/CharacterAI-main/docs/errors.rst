######
Errors
######

ServerError
===========

Any error on the server side

AuthError
=========

It means that you have the wrong token

NotFoundError
=============

The user's public account was not found

JSONError
=========

The server response contains a response that cannot be decoded in JSON. These can be either individual characters or the entire text, which may not be JSON