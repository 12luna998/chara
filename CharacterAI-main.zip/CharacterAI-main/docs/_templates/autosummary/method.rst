{{name | underline}}

.. automethod:: {{fullname}}