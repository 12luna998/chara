{{name | underline}}

.. autoclass:: {{fullname}}()